package com.kh.teamProject.controller;

import java.util.ArrayList;

import com.kh.teamProject.model.vo.Book;

public class BookController implements  BookManager{
	private ArrayList<Book> bList = new ArrayList<>();

	@Override
	public void addBook(Book nBook) {
		boolean  find = true;
		for(Book b : bList) {
			if(b.getbNo() == nBook.getbNo()) {
				System.out.println("도서명 : " + nBook.getbName()+"도서는 이미 있습니다.");
				find = false;
				break;
			}
		}
		if(find == true) {
			bList.add(nBook);
			System.out.println("도서명 : " + nBook.getbName()+"도서가 추가되었습니다.");
		}
		
	}

	@Override
	public ArrayList<Book> allBook() {
		return bList;
	}


	
}

/*
 * 다 반환하는 값을 가진 메소드로 제작
*/
