package com.kh.teamProject.run;

import com.kh.teamProject.view.LibraryView;

public class LibraryRun {

	public static void main(String[] args) {
		LibraryView lv = new LibraryView();
		lv.printBook();
		
	}

}
/*
 * 오직 실행만 하는 메인클래스
 */
